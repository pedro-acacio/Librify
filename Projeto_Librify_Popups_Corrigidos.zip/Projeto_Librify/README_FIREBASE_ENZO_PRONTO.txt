Firebase integrado - Parte do Enzo

O projeto já está configurado para salvar a parte do Enzo no Firebase Firestore.

Coleções usadas:
- publicacoes
- livros_catalogo

Fluxo implementado:
1. Usuário publica um livro.
2. O app salva no SQLite local.
3. O app também salva no Firebase na coleção publicacoes com status Pendente.
4. Admin aprova a publicação.
5. O app muda o status para Aprovado no SQLite e no Firebase.
6. O app salva o livro aprovado na coleção livros_catalogo.
7. Se o admin recusar, o status vira Recusado e o livro não entra no catálogo.

Arquivos principais alterados/conferidos:
- app/src/main/java/com/example/librify/MainActivity.java
- app/build.gradle
- app/google-services.json
- app/src/main/AndroidManifest.xml

Como testar:
1. Abrir o projeto no Android Studio.
2. Clicar em Sync Now.
3. Rodar o app.
4. Publicar um livro com usuário comum.
5. Conferir no Firebase > Firestore > publicacoes se apareceu o documento pub_ID.
6. Entrar como admin e aprovar.
7. Conferir se o status virou Aprovado em publicacoes e se apareceu em livros_catalogo.

Observação:
O login ainda continua usando o banco local SQLite do projeto. O Firebase foi integrado principalmente para o fluxo de publicação/aprovação do Enzo.
