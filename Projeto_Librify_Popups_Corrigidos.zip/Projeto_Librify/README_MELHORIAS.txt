Projeto Librify - versão funcional melhorada

Login:
- Senha Admin123 = entra como administrador.
- Senha Admin12 = entra como leitor comum.
- Qualquer outra senha mostra: "Senha ou email incorreto".

Melhorias realizadas:
- Visual mais moderno com fundos suaves, cards e botões padronizados.
- Navegação inferior funcional entre Home, Catálogo, Histórico, Publicar e Perfil.
- Catálogo com busca por título/autor/categoria.
- Filtros por categoria funcionando.
- Detalhes, reserva, lista e avaliação funcionando por simulação.
- Perfil, editar perfil, alterar senha, notificações e chat funcionando.
- Área administrativa disponível para Admin123.
- Tela Adicionar Livro agora funcional: cadastra um livro e ele aparece no catálogo durante a sessão do app.

Observação:
- O cadastro de livro é salvo em memória enquanto o aplicativo está aberto. Para salvar permanentemente, seria necessário banco de dados/localStorage/Room/Firebase.

Atualização - Publicações Pendentes
- A tela Publicar livro agora mantém a publicação em Minhas publicações com status pendente/em análise.
- Ao enviar um livro, ele aparece na Área Administrativa > Publicações Pendentes.
- O administrador pode aprovar ou recusar a publicação.
- Ao aprovar, o livro entra no catálogo automaticamente.
