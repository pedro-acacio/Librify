PARTE DO ENZO - INTEGRAÇÃO GERAL COM BANCO DE DADOS

Escolhi 2 áreas que não estavam designadas para o resto do grupo:

1) Publicação de livros do usuário
- Quando o usuário preenche a tela Publicar e envia um livro, os dados são salvos na tabela publicacoes.
- Campos salvos: email do usuário, título, autor, gênero, descrição, status e data de envio.
- A tela Minhas Publicações agora busca a última publicação do usuário no banco, então os dados não dependem só de variáveis em memória.

2) Administração de publicações pendentes / catálogo
- A tela de admin busca no banco a primeira publicação com status Pendente.
- Ao aprovar, o status da publicação muda para Aprovado e o livro é salvo na tabela livros_catalogo.
- Ao recusar, o status muda para Recusado.
- Livros cadastrados manualmente pelo admin também são salvos em livros_catalogo.
- O catálogo carrega o último livro salvo no banco como livro extra, então continua aparecendo depois de navegar pelas telas e reiniciar o app.

Tabelas novas criadas no DatabaseHelper.java:
- publicacoes
- livros_catalogo

Login admin para testar:
Email: admin@librify.com
Senha: Admin123

Como testar rápido:
1. Cadastre ou entre como usuário comum.
2. Vá em Publicar, preencha os dados e envie.
3. Entre como admin.
4. Vá em Perfil > Área administrativa > Publicações pendentes.
5. Aprove ou recuse a publicação.
6. Se aprovar, o livro aparece no Catálogo como livro extra vindo do banco de dados.


ATUALIZAÇÃO — CADASTRO DE ADMINISTRADOR
Agora, na tela de cadastro, se o usuário criar a conta usando a senha Admin123, o banco salva esse usuário com admin = 1.
Se a senha for diferente de Admin123, o usuário é salvo normalmente como leitor, com admin = 0.
Depois de finalizar o cadastro, o app volta para a tela de login. Assim o usuário precisa entrar novamente com o email e a senha que acabou de cadastrar.
Quando ele faz login, o app lê no banco se admin = 1 ou admin = 0 e libera a área administrativa somente para quem foi salvo como admin.

ATUALIZAÇÃO - AVALIAÇÃO NA MESMA PÁGINA E HISTÓRICO COM CAPA
-------------------------------------------------------------
1. A tela de detalhes do livro agora possui o card "Sua Avaliação" dentro da própria página.
   - Ao clicar em "Avaliar Livro", o card aparece abaixo dos botões do livro.
   - Ao enviar ou cancelar, o card some novamente.
   - Não é mais necessário abrir uma tela separada só para avaliar.

2. O histórico agora salva mais informações no banco de dados.
   Antes o histórico salvava apenas email, livro, autor e data.
   Agora também salva:
   - categoria
   - descrição
   - avaliação/rating
   - texto da capa
   - cor/fundo da capa
   - cor do texto da capa

3. Quando o usuário reserva um livro, o histórico mostra um card completo:
   - capa/foto do livro
   - título
   - autor
   - categoria
   - data da reserva
   - avaliação
   - descrição

Arquivos alterados nesta atualização:
- MainActivity.java
- DatabaseHelper.java
- activity_detalhes.xml
- activity_historico.xml

ATUALIZAÇÃO - AVALIAÇÕES E BOTÃO VOLTAR
---------------------------------------
1. Agora as avaliações são salvas no banco SQLite, na tabela `avaliacoes`.
   Campos principais: email, nome_usuario, livro, nota, comentario e data_envio.

2. Na tela de detalhes do livro, ao clicar em "Avaliar Livro", o formulário aparece na mesma página.
   Quando o usuário clica em "Enviar Avaliação", o app salva no banco e mostra a avaliação logo abaixo, com:
   - nome do usuário;
   - nota dada;
   - comentário;
   - data de envio.

3. Foi adicionado um botão global "← Voltar" nas telas internas do aplicativo.
   Esse botão direciona o usuário para a tela anterior/lógica principal de cada área.
