PROJETO LIBRIFY - FIREBASE AUTH + FIRESTORE

O que foi ajustado:

1) Cadastro no Firebase Authentication
- Ao cadastrar, o app cria a conta no Firebase Authentication com email e senha.
- Depois salva os dados extras do usuário na coleção usuarios do Firestore.
- Campos salvos em usuarios:
  uidUsuario
  nome
  email
  admin

2) Regra de admin
- Se a senha cadastrada for Admin123, o campo admin fica true no Firestore.
- Caso contrário, admin fica false.

3) Volta para login após cadastrar
- O Firebase faz login automático depois do cadastro.
- O código chama firebaseAuth.signOut() para obrigar o usuário a voltar para a tela de login.

4) Login pelo Firebase Authentication
- O login principal agora usa signInWithEmailAndPassword.
- Após logar, o app busca os dados do usuário na coleção usuarios.
- O app define nomeUsuario, emailUsuario e usuarioAdmin com base no Firestore.

5) Cópia local no SQLite
- O projeto ainda mantém uma cópia local no SQLite para as telas antigas continuarem funcionando.
- Isso evita quebrar publicação, histórico, perfil e outras partes que já usavam DatabaseHelper.

6) Recuperação de senha
- A tela de recuperação usa firebaseAuth.sendPasswordResetEmail.

7) Publicações do Enzo
- Ao publicar livro, salva no SQLite e no Firestore em publicacoes.
- Ao aprovar, muda status para Aprovado e salva em livros_catalogo.
- Ao recusar, muda status para Recusado.

Dependência adicionada:
implementation 'com.google.firebase:firebase-auth'

IMPORTANTE:
No Firebase Console, ative:
Authentication > Sign-in method > Email/Password > Enable
