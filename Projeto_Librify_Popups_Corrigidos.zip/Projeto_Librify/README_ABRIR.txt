Projeto Librify funcional - versão integrada com MyApplication3telas

Como abrir:
1. Extraia o ZIP.
2. No Android Studio, clique em File > Open.
3. Selecione a pasta Projeto_Librify_Funcional, não a pasta app.
4. Aguarde o Gradle Sync terminar.
5. Para rodar, escolha um dispositivo no topo. Se aparecer "No Devices", crie um em Device Manager ou conecte um celular com Depuração USB.

Logins de teste:
- Usuário comum: qualquer email + senha Admin12
- Administrador: qualquer email + senha Admin123
- Qualquer outra senha mostra: Senha incorreta

O que foi integrado:
- Tela Home do MyApplication3telas, adaptada para o projeto Java sem dependências extras.
- Navegação inferior funcional: Home, Catálogo, Histórico, Publicar e Perfil.
- Catálogo com 6 livros, detalhes, reserva, lista e avaliação.
- Telas reais para Editar Perfil, Notificações, Alterar Senha e Chat com Assistente.
- Painel Administrativo com Publicações Pendentes, Excluir e Definir Livro do Mês.
- Fluxos de login, cadastro e recuperação de senha conforme os requisitos do PDF.
