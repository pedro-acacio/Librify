GEMINI - CHAVE APLICADA

A chave informada pelo usuário foi colocada em:
app/src/main/java/com/example/librify/GeminiService.java

Também foi ajustada a chamada para usar a chave diretamente na URL:
https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=API_KEY

Se ainda aparecer erro 401, a chave informada não é uma API Key válida do Google AI Studio.
A API Key correta geralmente é criada no Google AI Studio em Get API key.
