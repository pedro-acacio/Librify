AJUSTES FEITOS NESTA VERSÃO

1. Mensagem de erro do login alterada para:
   "Senha ou email incorreto"

2. Removido o popup/toast que aparecia depois do cadastro:
   "Cadastro de administrador salvo no Firebase. Faça login para entrar."
   e também o equivalente de cadastro normal.

Agora, após cadastrar, o app volta direto para a tela de login sem mostrar esse segundo popup.
