package com.example.librify;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.FrameLayout;
import android.graphics.Typeface;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.animation.DecelerateInterpolator;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends android.app.Activity {
    private DatabaseHelper databaseHelper;
    private FirebaseFirestore firebaseDb;
    private FirebaseAuth firebaseAuth;
    private int telaAtualLayout = R.layout.activity_login;
    private String nomeUsuario = "Admin";
    private String emailUsuario = "admin@librify.com";
    private boolean usuarioAdmin = true;

    private String livroTitulo = "Duna";
    private String livroAutor = "Frank Herbert";
    private String livroCategoria = "Ficção Científica";
    private String livroDescricao = "A história do jovem Paul Atreides e sua jornada no deserto planeta Arrakis.";
    private String livroRating = "⭐ 4.6 (189 avaliações)";
    private String livroCapa = "DUNA";
    private int livroBackground = R.drawable.bg_book_red;
    private int livroTextColor = Color.WHITE;

    private String mesTitulo = "O Senhor dos Anéis";
    private String mesAutor = "J.R.R. Tolkien";
    private String mesDescricao = "Uma épica jornada pela Terra Média em busca da destruição do Um Anel.";
    private String mesRating = "⭐ 4.8 (234 avaliações)";
    private String mesCapa = "Capa";
    private String mesCategoria = "Fantasia";
    private int mesBackground = R.drawable.bg_book_blue;
    private int mesTextColor = Color.rgb(17, 24, 39);

    private boolean livroExtraCadastrado = false;
    private String extraTitulo = "";
    private String extraAutor = "";
    private String extraCategoria = "";
    private String extraDescricao = "";
    private String filtroAtual = "Todos";

    private boolean publicacaoEnviada = false;
    private int publicacaoIdAtual = -1;
    private int publicacaoPendenteAdminId = -1;
    private String publicacaoStatus = "";
    private String publicacaoTitulo = "";
    private String publicacaoAutor = "";
    private String publicacaoGenero = "";
    private String publicacaoDescricao = "";
    private String publicacaoEmail = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        databaseHelper = new DatabaseHelper(this);
        firebaseDb = FirebaseFirestore.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();

        carregarLivroExtraDoBanco();
        mostrarLogin();
    }

    private void abrirTela(int layoutId) {
        telaAtualLayout = layoutId;
        setContentView(layoutId);
        animarEntrada();
        configurarNavInferior();
        destacarNav(layoutId);
        configurarBotaoVoltarGlobal();
    }

    private void mostrarLogin() {
        telaAtualLayout = R.layout.activity_login;
        setContentView(R.layout.activity_login);
        animarEntrada();
        clicar(R.id.btnEntrar, v -> validarLogin());
        clicar(R.id.btnIrCadastro, v -> mostrarCadastro());
        clicar(R.id.btnEsqueceuSenha, v -> mostrarRecuperarSenha());
    }

    private void validarLogin() {
        EditText email = findViewById(R.id.edtLoginEmail);
        EditText senha = findViewById(R.id.edtLoginSenha);
        TextView erro = findViewById(R.id.txtLoginErro);
        String emailTxt = texto(email);
        String senhaTxt = texto(senha);

        if (emailTxt.isEmpty() || senhaTxt.isEmpty()) {
            mostrarErro(erro, "Preencha todos os campos");
            return;
        }

        // Login principal pelo Firebase Authentication.
        firebaseAuth.signInWithEmailAndPassword(emailTxt, senhaTxt)
                .addOnSuccessListener(authResult -> {
                    FirebaseUser usuarioFirebase = firebaseAuth.getCurrentUser();
                    if (usuarioFirebase == null) {
                        mostrarErro(erro, "Não foi possível carregar o usuário do Firebase");
                        return;
                    }

                    firebaseDb.collection("usuarios")
                            .document(usuarioFirebase.getUid())
                            .get()
                            .addOnSuccessListener(document -> {
                                if (document.exists()) {
                                    String nomeFirebase = document.getString("nome");
                                    String emailFirebase = document.getString("email");
                                    Boolean adminFirebase = document.getBoolean("admin");

                                    nomeUsuario = nomeFirebase == null || nomeFirebase.isEmpty() ? "Usuário" : nomeFirebase;
                                    emailUsuario = emailFirebase == null || emailFirebase.isEmpty() ? emailTxt : emailFirebase;
                                    usuarioAdmin = adminFirebase != null && adminFirebase;
                                } else {
                                    nomeUsuario = "Usuário";
                                    emailUsuario = emailTxt;
                                    usuarioAdmin = senhaTxt.equals("Admin123");
                                    salvarUsuarioFirestore(usuarioFirebase.getUid(), nomeUsuario, emailUsuario, usuarioAdmin);
                                }

                                // Mantém uma cópia local para as partes antigas do projeto continuarem funcionando.
                                databaseHelper.cadastrarUsuario(nomeUsuario, emailUsuario, senhaTxt);
                                mostrarHome();
                            })
                            .addOnFailureListener(e -> {
                                mostrarErro(erro, "Login feito, mas não foi possível buscar dados do usuário: " + e.getMessage());
                            });
                })
                .addOnFailureListener(e -> {
                    // Fallback para contas antigas que estavam somente no SQLite.
                    android.database.Cursor cursor = databaseHelper.validarUsuario(emailTxt, senhaTxt);

                    if (cursor.moveToFirst()) {
                        nomeUsuario = cursor.getString(cursor.getColumnIndexOrThrow("nome"));
                        emailUsuario = cursor.getString(cursor.getColumnIndexOrThrow("email"));
                        usuarioAdmin = cursor.getInt(cursor.getColumnIndexOrThrow("admin")) == 1;
                        cursor.close();
                        toast("Login local realizado. Para aparecer no Firebase, cadastre essa conta no Authentication.");
                        mostrarHome();
                    } else {
                        cursor.close();
                        mostrarErro(erro, "Senha ou email incorreto");
                    }
                });
    }

    private void mostrarCadastro() {
        telaAtualLayout = R.layout.activity_cadastro;
        setContentView(R.layout.activity_cadastro);
        animarEntrada();
        configurarBotaoVoltarGlobal();
        clicar(R.id.btnCadastrar, v -> validarCadastro());
        clicar(R.id.btnIrLogin, v -> mostrarLogin());
    }

    private void validarCadastro() {
        EditText nome = findViewById(R.id.edtNome);
        EditText email = findViewById(R.id.edtCadastroEmail);
        EditText senha = findViewById(R.id.edtCadastroSenha);
        TextView erro = findViewById(R.id.txtCadastroErro);

        String nomeTxt = texto(nome);
        String emailTxt = texto(email);
        String senhaTxt = texto(senha);

        if (nomeTxt.isEmpty() || emailTxt.isEmpty() || senhaTxt.isEmpty()) {
            mostrarErro(erro, "Preencha todos os campos");
            return;
        }

        boolean temOito = senhaTxt.length() >= 8;
        boolean temNumero = senhaTxt.matches(".*\\d.*");
        boolean temMaiuscula = senhaTxt.matches(".*[A-Z].*");

        if (!temOito || !temNumero || !temMaiuscula) {
            mostrarErro(erro, "A senha deve ter pelo menos 8 caracteres, incluindo um número e uma letra maiúscula");
            return;
        }

        // Cadastro principal pelo Firebase Authentication.
        firebaseAuth.createUserWithEmailAndPassword(emailTxt, senhaTxt)
                .addOnSuccessListener(authResult -> {
                    FirebaseUser usuarioFirebase = firebaseAuth.getCurrentUser();
                    if (usuarioFirebase == null) {
                        mostrarErro(erro, "Cadastro criado, mas não foi possível carregar o usuário do Firebase");
                        return;
                    }

                    boolean cadastroAdmin = senhaTxt.equals("Admin123");
                    salvarUsuarioFirestore(usuarioFirebase.getUid(), nomeTxt, emailTxt, cadastroAdmin);

                    // Mantém uma cópia local para as telas antigas que usam SQLite.
                    databaseHelper.cadastrarUsuario(nomeTxt, emailTxt, senhaTxt);

                    nomeUsuario = "";
                    emailUsuario = "";
                    usuarioAdmin = false;

                    // O Firebase faz login automático depois do cadastro. Como o professor pediu,
                    // aqui fazemos logout para obrigar o usuário a voltar e entrar pela tela de login.
                    firebaseAuth.signOut();

                    // Volta direto para a tela de login sem exibir popup/toast de cadastro.
                    mostrarLogin();
                })
                .addOnFailureListener(e -> {
                    mostrarErro(erro, "Erro ao cadastrar no Firebase: " + e.getMessage());
                });
    }

    private void salvarUsuarioFirestore(String uid, String nome, String email, boolean admin) {
        Map<String, Object> usuario = new HashMap<>();
        usuario.put("uidUsuario", uid);
        usuario.put("nome", nome);
        usuario.put("email", email);
        usuario.put("admin", admin);

        firebaseDb.collection("usuarios")
                .document(uid)
                .set(usuario)
                .addOnFailureListener(e -> toast("Erro ao salvar usuário no Firestore: " + e.getMessage()));
    }

    private void mostrarRecuperarSenha() {
        telaAtualLayout = R.layout.activity_recuperar_senha;
        setContentView(R.layout.activity_recuperar_senha);
        animarEntrada();
        configurarBotaoVoltarGlobal();
        clicar(R.id.btnVoltarLogin, v -> mostrarLogin());
        clicar(R.id.btnEnviarRecuperacao, v -> {
            EditText email = findViewById(R.id.edtRecuperarEmail);
            TextView msg = findViewById(R.id.txtRecoveryMessage);
            String emailTxt = texto(email);

            if (emailTxt.isEmpty()) {
                Toast.makeText(this, "Informe seu email", Toast.LENGTH_SHORT).show();
                return;
            }

            firebaseAuth.sendPasswordResetEmail(emailTxt)
                    .addOnSuccessListener(aVoid -> {
                        if (msg != null) {
                            msg.setText("Enviamos um link de recuperação para seu email.");
                            msg.setVisibility(View.VISIBLE);
                        }
                    })
                    .addOnFailureListener(e -> {
                        if (msg != null) {
                            msg.setText("Não foi possível enviar recuperação: " + e.getMessage());
                            msg.setVisibility(View.VISIBLE);
                        }
                    });
        });
    }

    private void mostrarHome() {
        abrirTela(R.layout.activity_home);
        TextView saudacao = findViewById(R.id.txtSaudacao);
        if (saudacao != null) saudacao.setText("Olá, " + nomeUsuario + "!");
        atualizarLivroMesNaHome();
        clicar(R.id.btnLivroMesDetalhes, v -> {
            selecionarLivro(mesTitulo, mesAutor, mesCategoria, mesDescricao, mesRating, mesCapa, mesBackground, mesTextColor);
            mostrarDetalhes();
        });
        clicar(R.id.cardDunaDestaque, v -> abrirLivroDuna());
        clicar(R.id.cardCellsDestaque, v -> abrirLivroCells());
        clicar(R.id.cardDavinci, v -> abrirLivroDavinci());
    }

    private void mostrarCatalogo() {
        abrirTela(R.layout.activity_catalogo);
        atualizarLivroExtraNoCatalogo();
        configurarBuscaCatalogo();
        clicar(R.id.cardLivro1, v -> abrirLivroSenhor());
        clicar(R.id.cardLivro2, v -> abrirLivroDuna());
        clicar(R.id.cardLivro3, v -> abrirLivroCells());
        clicar(R.id.cardLivro4, v -> abrirLivroDavinci());
        clicar(R.id.cardLivro5, v -> abrirLivroOrgulho());
        clicar(R.id.cardLivro6, v -> abrirLivro1984());
        clicar(R.id.cardLivroExtra, v -> abrirLivroExtra());
        clicar(R.id.chipTodos, v -> aplicarFiltroCatalogo("Todos"));
        clicar(R.id.chipFantasia, v -> aplicarFiltroCatalogo("Fantasia"));
        clicar(R.id.chipFiccao, v -> aplicarFiltroCatalogo("Ficção Científica"));
        clicar(R.id.chipRomance, v -> aplicarFiltroCatalogo("Romance"));
        aplicarFiltroCatalogo(filtroAtual);
    }

    private String historicoTexto = "";
    private String ultimaAvaliacao = "";

    private void mostrarDetalhes() {
        abrirTela(R.layout.activity_detalhes);
        atualizarTelaDetalhes();
        atualizarAvaliacoesDoLivro();
        esconderCardAvaliacao();
        clicar(R.id.btnReservar, v -> reservarLivro());
        clicar(R.id.btnAdicionarLista, v -> toast("Livro adicionado à lista"));

        // Agora a avaliação aparece na própria página do livro, sem abrir outra tela.
        clicar(R.id.btnAvaliar, v -> exibirCardAvaliacao());
        clicar(R.id.btnEnviarAvaliacao, v -> enviarAvaliacaoNaMesmaPagina());
        clicar(R.id.btnCancelarAvaliacao, v -> esconderCardAvaliacao());
    }

    private void exibirCardAvaliacao() {
        View card = findViewById(R.id.cardAvaliacaoDetalhe);
        if (card != null) {
            card.setVisibility(View.VISIBLE);
            card.requestFocus();
        }
    }

    private void esconderCardAvaliacao() {
        View card = findViewById(R.id.cardAvaliacaoDetalhe);
        if (card != null) card.setVisibility(View.GONE);
    }

    private void enviarAvaliacaoNaMesmaPagina() {
        EditText campo = findViewById(R.id.edtComentario);
        RatingBar ratingBar = findViewById(R.id.ratingLivro);
        String comentario = texto(campo);
        int nota = ratingBar == null ? 5 : Math.round(ratingBar.getRating());
        if (nota <= 0) nota = 1;
        if (comentario.isEmpty()) comentario = "Sem comentário.";

        String data = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        boolean salvo = databaseHelper.salvarAvaliacao(
                emailUsuario,
                nomeUsuario,
                livroTitulo,
                nota,
                comentario,
                data
        );

        if (!salvo) {
            toast("Não foi possível salvar a avaliação");
            return;
        }

        ultimaAvaliacao = comentario;
        if (campo != null) campo.setText("");
        if (ratingBar != null) ratingBar.setRating(5);

        atualizarAvaliacoesDoLivro();
        toast("Avaliação enviada com sucesso");
        esconderCardAvaliacao();
    }

    private void mostrarAvaliacao() {
        abrirTela(R.layout.activity_avaliacao);
        atualizarTelaAvaliacao();
        clicar(R.id.btnEnviarAvaliacao, v -> {
            EditText campo = findViewById(R.id.edtComentario);
            if(campo != null){ ultimaAvaliacao = texto(campo); }
            toast("Avaliação enviada com sucesso");
            mostrarDetalhes();
        });
        clicar(R.id.btnCancelarAvaliacao, v -> mostrarDetalhes());
    }

    private void atualizarAvaliacoesDoLivro() {
        LinearLayout lista = findViewById(R.id.layoutAvaliacoesLivro);
        TextView vazio = findViewById(R.id.txtSemAvaliacoes);
        if (lista == null) return;

        lista.removeAllViews();
        android.database.Cursor c = databaseHelper.getAvaliacoesLivro(livroTitulo);
        boolean temAvaliacao = false;

        while (c.moveToNext()) {
            temAvaliacao = true;
            String nome = coluna(c, "nome_usuario", "Usuário");
            int nota = colunaInt(c, "nota", 5);
            String comentario = coluna(c, "comentario", "Sem comentário.");
            String data = coluna(c, "data_envio", "");
            adicionarCardAvaliacaoLivro(lista, nome, nota, comentario, data);
        }
        c.close();

        if (vazio != null) vazio.setVisibility(temAvaliacao ? View.GONE : View.VISIBLE);
    }

    private void adicionarCardAvaliacaoLivro(LinearLayout lista, String nome, int nota, String comentario, String data) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, dp(10));
        card.setLayoutParams(params);

        TextView nomeView = criarTextoHistorico(nome, 15, Color.rgb(17, 24, 39), true);
        TextView notaView = criarTextoHistorico("Nota: " + estrelas(nota) + "  (" + nota + "/5)", 13, Color.rgb(0, 128, 115), false);
        TextView comentarioView = criarTextoHistorico("Comentário: " + comentario, 13, Color.rgb(75, 85, 99), false);
        TextView dataView = criarTextoHistorico(data.isEmpty() ? "" : "Enviado em: " + data, 11, Color.rgb(107, 114, 128), false);

        card.addView(nomeView);
        card.addView(notaView);
        card.addView(comentarioView);
        if (!data.isEmpty()) card.addView(dataView);
        lista.addView(card);
    }

    private String estrelas(int nota) {
        StringBuilder sb = new StringBuilder();
        int n = Math.max(1, Math.min(5, nota));
        for (int i = 1; i <= 5; i++) sb.append(i <= n ? "★" : "☆");
        return sb.toString();
    }

    private void mostrarHistorico() {
        abrirTela(R.layout.activity_historico);
        carregarHistorico();
        clicar(R.id.btnAtuais, v -> carregarHistorico());
        clicar(R.id.btnHistoricoAba, v -> carregarHistorico());
    }

    private void reservarLivro() {
        String data = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        // O histórico agora salva também os dados visuais do livro, para aparecer com capa/foto e informações.
        databaseHelper.salvarHistorico(
                emailUsuario,
                livroTitulo,
                livroAutor,
                data,
                livroCategoria,
                livroDescricao,
                livroRating,
                livroCapa,
                livroBackground,
                livroTextColor
        );
        toast("Livro reservado com sucesso");
    }

    private void carregarHistorico() {
        android.database.Cursor c = databaseHelper.getHistorico(emailUsuario);
        LinearLayout lista = findViewById(R.id.layoutHistoricoLista);
        TextView msg = findViewById(R.id.txtHistoricoMensagem);

        if (lista != null) lista.removeAllViews();

        boolean temHistorico = false;
        while(c.moveToNext()) {
            temHistorico = true;

            String titulo = coluna(c, "livro", "Livro");
            String autor = coluna(c, "autor", "Autor não informado");
            String data = coluna(c, "data", "");
            String categoria = coluna(c, "categoria", "Categoria não informada");
            String descricao = coluna(c, "descricao", "Sem descrição cadastrada");
            String rating = coluna(c, "rating", "⭐ Livro reservado");
            String capa = coluna(c, "capa", gerarCapaTexto(titulo));
            int capaBackground = colunaInt(c, "capa_background", R.drawable.bg_book_blue);
            int capaTextColor = colunaInt(c, "capa_text_color", Color.rgb(17, 24, 39));

            if (lista != null) {
                adicionarCardHistorico(lista, titulo, autor, data, categoria, descricao, rating, capa, capaBackground, capaTextColor);
            }
        }

        if (msg != null) {
            msg.setVisibility(temHistorico ? View.GONE : View.VISIBLE);
            msg.setText("Você não possui livros emprestados ou reservados no momento");
        }

        c.close();
    }

    private void adicionarCardHistorico(LinearLayout lista, String titulo, String autor, String data, String categoria, String descricao, String rating, String capa, int capaBackground, int capaTextColor) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setBackgroundResource(R.drawable.bg_card);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.setGravity(android.view.Gravity.CENTER_VERTICAL);

        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardParams.setMargins(0, 0, 0, dp(14));
        card.setLayoutParams(cardParams);

        TextView capaView = new TextView(this);
        capaView.setText(capa);
        capaView.setGravity(android.view.Gravity.CENTER);
        capaView.setTextSize(18);
        capaView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        capaView.setTextColor(capaTextColor);
        capaView.setBackgroundResource(capaBackground == 0 ? R.drawable.bg_book_blue : capaBackground);
        LinearLayout.LayoutParams capaParams = new LinearLayout.LayoutParams(dp(92), dp(128));
        capaParams.setMargins(0, 0, dp(12), 0);
        card.addView(capaView, capaParams);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        card.addView(info, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        TextView tituloView = criarTextoHistorico(titulo, 17, Color.rgb(17, 24, 39), true);
        TextView autorView = criarTextoHistorico("Autor: " + autor, 13, Color.rgb(85, 85, 85), false);
        TextView categoriaView = criarTextoHistorico("Categoria: " + categoria, 12, Color.rgb(37, 99, 235), false);
        TextView dataView = criarTextoHistorico("Reservado em: " + data, 12, Color.rgb(107, 114, 128), false);
        TextView ratingView = criarTextoHistorico(rating, 12, Color.rgb(80, 80, 80), false);
        TextView descricaoView = criarTextoHistorico(descricao, 12, Color.rgb(75, 85, 99), false);
        descricaoView.setMaxLines(3);

        info.addView(tituloView);
        info.addView(autorView);
        info.addView(categoriaView);
        info.addView(dataView);
        info.addView(ratingView);
        info.addView(descricaoView);

        lista.addView(card);
    }

    private TextView criarTextoHistorico(String texto, int tamanho, int cor, boolean negrito) {
        TextView tv = new TextView(this);
        tv.setText(texto);
        tv.setTextSize(tamanho);
        tv.setTextColor(cor);
        if (negrito) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        tv.setPadding(0, 0, 0, dp(4));
        return tv;
    }

    private String coluna(android.database.Cursor c, String nome, String padrao) {
        int index = c.getColumnIndex(nome);
        if (index == -1 || c.isNull(index)) return padrao;
        return c.getString(index);
    }

    private int colunaInt(android.database.Cursor c, String nome, int padrao) {
        int index = c.getColumnIndex(nome);
        if (index == -1 || c.isNull(index)) return padrao;
        return c.getInt(index);
    }

    private String gerarCapaTexto(String titulo) {
        if (titulo == null || titulo.trim().isEmpty()) return "LIVRO";
        String limpo = titulo.trim();
        return limpo.length() > 7 ? limpo.substring(0, 7).toUpperCase() : limpo.toUpperCase();
    }

    private void setHistorico(String texto) {
        TextView msg = findViewById(R.id.txtHistoricoMensagem);
        if (msg != null) msg.setText(texto);
    }

    private void mostrarPublicar() {
        abrirTela(R.layout.activity_publicar);
        atualizarMinhasPublicacoes();
        clicar(R.id.btnUploadPdf, v -> {
            setTexto(R.id.txtPdfSelecionado, "PDF selecionado: livro.pdf");
            toast("Seleção de PDF simulada");
        });
        clicar(R.id.btnEnviarLivro, v -> publicarLivroUsuario());  // Enzo 7
    }



    //Enzo 8
    private void publicarLivroUsuario() {
        EditText titulo = findViewById(R.id.edtTituloLivro);
        EditText autor = findViewById(R.id.edtAutorLivro);
        EditText genero = findViewById(R.id.edtGeneroLivro);
        EditText descricao = findViewById(R.id.edtDescricaoLivro);
        TextView erro = findViewById(R.id.txtPublicarErro);

        String tituloTxt = texto(titulo);
        String autorTxt = texto(autor);
        String generoTxt = texto(genero);
        String descricaoTxt = texto(descricao);

        if (tituloTxt.isEmpty() || autorTxt.isEmpty() || generoTxt.isEmpty() || descricaoTxt.isEmpty()) {
            mostrarErro(erro, "Preencha todos os campos para publicar o livro");
            return;
        }

        if (erro != null) erro.setVisibility(View.GONE);

        String data = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        boolean salvo = databaseHelper.salvarPublicacao(
                emailUsuario,
                tituloTxt,
                autorTxt,
                generoTxt,
                descricaoTxt,
                data
        );

        if (!salvo) {
            mostrarErro(erro, "Não foi possível salvar a publicação no banco de dados");
            return;
        }

        carregarMinhaPublicacaoAtual();

        Map<String, Object> publicacaoFirebase = new HashMap<>();
        publicacaoFirebase.put("idLocal", publicacaoIdAtual);
        publicacaoFirebase.put("uidUsuario", emailUsuario);
        publicacaoFirebase.put("email", emailUsuario);
        publicacaoFirebase.put("nome_usuario", nomeUsuario);
        publicacaoFirebase.put("titulo", tituloTxt);
        publicacaoFirebase.put("autor", autorTxt);
        publicacaoFirebase.put("genero", generoTxt);
        publicacaoFirebase.put("descricao", descricaoTxt);
        publicacaoFirebase.put("status", "Pendente");
        publicacaoFirebase.put("data_envio", data);

        firebaseDb.collection("publicacoes")
                .document("pub_" + publicacaoIdAtual)
                .set(publicacaoFirebase)
                .addOnSuccessListener(aVoid -> {
                    toast("Livro salvo no Firebase e enviado para análise");
                })
                .addOnFailureListener(e -> {
                    toast("Erro ao salvar no Firebase: " + e.getMessage());
                });

        if (titulo != null) titulo.setText("");
        if (autor != null) autor.setText("");
        if (genero != null) genero.setText("");
        if (descricao != null) descricao.setText("");

        setTexto(R.id.txtPdfSelecionado, "Clique para selecionar o PDF");

        atualizarMinhasPublicacoes();
    }


    private void carregarMinhaPublicacaoAtual() {
        android.database.Cursor c = databaseHelper.getMinhaUltimaPublicacao(emailUsuario);
        publicacaoEnviada = c.moveToFirst();
        if (publicacaoEnviada) {
            publicacaoIdAtual = c.getInt(c.getColumnIndexOrThrow("id"));
            publicacaoEmail = c.getString(c.getColumnIndexOrThrow("email"));
            publicacaoTitulo = c.getString(c.getColumnIndexOrThrow("titulo"));
            publicacaoAutor = c.getString(c.getColumnIndexOrThrow("autor"));
            publicacaoGenero = c.getString(c.getColumnIndexOrThrow("genero"));
            publicacaoDescricao = c.getString(c.getColumnIndexOrThrow("descricao"));
            publicacaoStatus = c.getString(c.getColumnIndexOrThrow("status"));
        } else {
            publicacaoIdAtual = -1;
            publicacaoEmail = "";
            publicacaoTitulo = "";
            publicacaoAutor = "";
            publicacaoGenero = "";
            publicacaoDescricao = "";
            publicacaoStatus = "";
        }
        c.close();
    }

    private void atualizarMinhasPublicacoes() {
        carregarMinhaPublicacaoAtual();
        View vazio = findViewById(R.id.cardSemPublicacoes);
        View card = findViewById(R.id.cardMinhaPublicacao);
        if (vazio != null) vazio.setVisibility(publicacaoEnviada ? View.GONE : View.VISIBLE);
        if (card != null) card.setVisibility(publicacaoEnviada ? View.VISIBLE : View.GONE);
        if (!publicacaoEnviada) return;
        String statusTela = publicacaoStatus.isEmpty() ? "Pendente" : publicacaoStatus;
        setTexto(R.id.txtMinhaPublicacaoStatus, statusTela.equals("Pendente") ? "Pendente / Em análise" : statusTela);
        setTexto(R.id.txtMinhaPublicacaoTitulo, publicacaoTitulo);
        setTexto(R.id.txtMinhaPublicacaoAutor, "Autor: " + publicacaoAutor);
        setTexto(R.id.txtMinhaPublicacaoGenero, "Gênero: " + publicacaoGenero);
        setTexto(R.id.txtMinhaPublicacaoDescricao, publicacaoDescricao);
    }

    private void mostrarStatusPublicacao() {
        abrirTela(R.layout.activity_status_publicacao);
        clicar(R.id.btnSelecionarPdfStatus, v -> toast("Seleção de PDF simulada"));
        clicar(R.id.btnEnviarAvaliacaoLivro, v -> toast("Publicação enviada para análise"));
    }

    private void mostrarPerfil() {
        abrirTela(R.layout.activity_perfil);
        TextView nome = findViewById(R.id.txtPerfilNome);
        TextView tipo = findViewById(R.id.txtPerfilTipo);
        View admin = findViewById(R.id.btnAdmin);
        if (nome != null) nome.setText(nomeUsuario);
        if (tipo != null) tipo.setText(usuarioAdmin ? "Administrador" : "Leitor");
        if (admin != null) admin.setVisibility(usuarioAdmin ? View.VISIBLE : View.GONE);
        clicar(R.id.btnEditarPerfil, v -> mostrarEditarPerfil());
        clicar(R.id.btnNotificacoes, v -> mostrarNotificacoes());
        clicar(R.id.btnAlterarSenha, v -> mostrarAlterarSenha());
        clicar(R.id.btnChat, v -> mostrarChat());
        clicar(R.id.btnAdmin, v -> mostrarAdmin());
        clicar(R.id.btnSair, v -> mostrarLogin());
    }

    private void mostrarEditarPerfil() {
        abrirTela(R.layout.activity_editar_perfil);
        EditText nome = findViewById(R.id.edtEditarNome);
        if (nome != null) nome.setText(nomeUsuario);
        clicar(R.id.btnVoltarEditarPerfil, v -> mostrarPerfil());
        clicar(R.id.btnCancelarPerfil, v -> mostrarPerfil());
        clicar(R.id.btnSalvarPerfil, v -> {
            EditText campo = findViewById(R.id.edtEditarNome);
            if (texto(campo).isEmpty()) {
                toast("Informe seu nome");
            } else {
                nomeUsuario = texto(campo);
                databaseHelper.atualizarNome(emailUsuario, nomeUsuario);
                toast("Perfil atualizado");
                mostrarPerfil();
            }
        });
    }

    private void mostrarNotificacoes() {
        abrirTela(R.layout.activity_notificacoes);
        clicar(R.id.btnVoltarNotificacoes, v -> mostrarPerfil());
    }

    private void mostrarAlterarSenha() {
        abrirTela(R.layout.activity_alterar_senha);
        clicar(R.id.btnVoltarAlterarSenha, v -> mostrarPerfil());
        clicar(R.id.btnCancelarAlterarSenha, v -> mostrarPerfil());
        clicar(R.id.btnConfirmarAlterarSenha, v -> validarAlterarSenha());
    }

    private void validarAlterarSenha() {
        EditText nova = findViewById(R.id.edtNovaSenha);
        EditText confirmar = findViewById(R.id.edtConfirmarSenha);
        TextView msg = findViewById(R.id.txtAlterarSenhaMsg);
        String s1 = texto(nova);
        String s2 = texto(confirmar);
        if (s1.isEmpty() || s2.isEmpty()) {
            mostrarErro(msg, "Preencha todos os campos");
            return;
        }
        if (!s1.equals(s2)) {
            mostrarErro(msg, "As senhas não conferem");
            return;
        }
        if (s1.length() < 8 || !s1.matches(".*\\d.*") || !s1.matches(".*[A-Z].*")) {
            mostrarErro(msg, "A senha deve ter pelo menos 8 caracteres, incluindo um número e uma letra maiúscula");
            return;
        }
        databaseHelper.atualizarSenha(emailUsuario, s1);
        toast("Senha alterada com sucesso");
        mostrarPerfil();
    }

    private void mostrarChat() {
        abrirTela(R.layout.activity_chat);

        clicar(R.id.btnVoltarChat, v -> mostrarPerfil());

        EditText campo = findViewById(R.id.edtMensagemChat);
        TextView usuario = findViewById(R.id.txtChatUsuario);
        TextView resposta = findViewById(R.id.txtChatResposta);

        clicar(R.id.btnEnviarChat, v -> {
            String mensagem = texto(campo).trim();

            if (mensagem.isEmpty()) {
                toast("Digite sua mensagem");
                return;
            }

            if (usuario != null) {
                usuario.setText(mensagem);
                usuario.setVisibility(View.VISIBLE);
            }

            if (resposta != null) {
                resposta.setText("Pensando...");
                resposta.setVisibility(View.VISIBLE);
            }

            if (campo != null) {
                campo.setText("");
            }

            GeminiService.perguntar(
                    mensagem,
                    new GeminiService.GeminiCallback() {
                        @Override
                        public void onResponse(String textoResposta) {
                            runOnUiThread(() -> {
                                if (resposta != null) {
                                    resposta.setText(textoResposta);
                                    resposta.setVisibility(View.VISIBLE);
                                }
                            });
                        }

                        @Override
                        public void onError(String erro) {
                            runOnUiThread(() -> {
                                if (resposta != null) {
                                    resposta.setText("Erro: " + erro);
                                    resposta.setVisibility(View.VISIBLE);
                                }
                            });
                        }
                    }
            );
        });
    }

    private void mostrarAdmin() {
        if (!usuarioAdmin) {
            toast("Acesso restrito ao administrador");
            mostrarPerfil();
            return;
        }
        abrirTela(R.layout.activity_admin);
        clicar(R.id.btnVoltarPerfil, v -> mostrarPerfil());
        clicar(R.id.btnVerPendentes, v -> mostrarAdminPendentes());
        clicar(R.id.btnAdicionarLivroAdmin, v -> mostrarAdicionarLivro());
        clicar(R.id.btnExcluirSenhor, v -> toast("Livro excluído do catálogo (simulado)"));
        clicar(R.id.btnExcluirDuna, v -> toast("Livro excluído do catálogo (simulado)"));
        clicar(R.id.btnLivroMesSenhor, v -> {
            definirLivroMes("O Senhor dos Anéis", "J.R.R. Tolkien", "Fantasia", "Uma épica jornada pela Terra Média em busca da destruição do Um Anel.", "⭐ 4.8 (234 avaliações)", "Capa", R.drawable.bg_book_blue, Color.rgb(17, 24, 39));
            toast("Livro do Mês atualizado");
            mostrarHome();
        });
        clicar(R.id.btnLivroMesDuna, v -> {
            definirLivroMes("Duna", "Frank Herbert", "Ficção Científica", "A história do jovem Paul Atreides e sua jornada no deserto planeta Arrakis.", "⭐ 4.6 (189 avaliações)", "DUNA", R.drawable.bg_book_red, Color.WHITE);
            toast("Livro do Mês atualizado");
            mostrarHome();
        });
    }

    private void mostrarAdicionarLivro() {
        telaAtualLayout = R.layout.activity_adicionar_livro;
        setContentView(R.layout.activity_adicionar_livro);
        animarEntrada();
        configurarBotaoVoltarGlobal();
        clicar(R.id.btnVoltarLoginAddLivro, v -> mostrarLogin());
        clicar(R.id.btnVoltarAdminAddLivro, v -> mostrarAdmin());
        clicar(R.id.btnSalvarLivro, v -> salvarLivroExtra());
    }

    private void salvarLivroExtra() {
        EditText titulo = findViewById(R.id.edtLivroTitulo);
        EditText autor = findViewById(R.id.edtLivroAutor);
        EditText categoria = findViewById(R.id.edtLivroCategoria);
        EditText descricao = findViewById(R.id.edtLivroDescricao);
        TextView erro = findViewById(R.id.txtAdicionarLivroErro);

        if (texto(titulo).isEmpty() || texto(autor).isEmpty() || texto(categoria).isEmpty() || texto(descricao).isEmpty()) {
            mostrarErro(erro, "Preencha todos os campos para cadastrar o livro");
            return;
        }

        boolean salvo = databaseHelper.salvarLivroCatalogo(
                texto(titulo),
                texto(autor),
                texto(categoria),
                texto(descricao),
                "Cadastrado pelo administrador"
        );

        if (!salvo) {
            mostrarErro(erro, "Não foi possível salvar o livro no banco de dados");
            return;
        }

        carregarLivroExtraDoBanco();
        toast("Livro salvo no banco e cadastrado no catálogo");
        mostrarCatalogo();
    }



    // Enzo 8
    private void mostrarAdminPendentes() {
        abrirTela(R.layout.activity_admin_pendentes);
        atualizarAdminPendentes();
        clicar(R.id.btnVoltarAdminPendentes, v -> mostrarAdmin());
        clicar(R.id.btnAdminLivrosPendentes, v -> mostrarAdmin());
        clicar(R.id.btnAprovarPublicacao, v -> aprovarPublicacao());
        clicar(R.id.btnRecusarPublicacao, v -> recusarPublicacao());
    }


    // Enzo 9
    private boolean carregarPublicacaoPendenteDoBanco() {
        android.database.Cursor c = databaseHelper.getPrimeiraPublicacaoPendente();
        boolean temPendente = c.moveToFirst();
        if (temPendente) {
            publicacaoPendenteAdminId = c.getInt(c.getColumnIndexOrThrow("id"));
            publicacaoEmail = c.getString(c.getColumnIndexOrThrow("email"));
            publicacaoTitulo = c.getString(c.getColumnIndexOrThrow("titulo"));
            publicacaoAutor = c.getString(c.getColumnIndexOrThrow("autor"));
            publicacaoGenero = c.getString(c.getColumnIndexOrThrow("genero"));
            publicacaoDescricao = c.getString(c.getColumnIndexOrThrow("descricao"));
            publicacaoStatus = c.getString(c.getColumnIndexOrThrow("status"));
        } else {
            publicacaoPendenteAdminId = -1;
            publicacaoEmail = "";
            publicacaoTitulo = "";
            publicacaoAutor = "";
            publicacaoGenero = "";
            publicacaoDescricao = "";
            publicacaoStatus = "";
        }
        c.close();
        return temPendente;
    }

    private void atualizarAdminPendentes() {
        boolean temPendente = carregarPublicacaoPendenteDoBanco();
        View vazio = findViewById(R.id.cardAdminSemPendentes);
        View card = findViewById(R.id.cardAdminPublicacaoPendente);
        if (vazio != null) vazio.setVisibility(temPendente ? View.GONE : View.VISIBLE);
        if (card != null) card.setVisibility(temPendente ? View.VISIBLE : View.GONE);
        if (!temPendente) return;
        setTexto(R.id.txtAdminPendenteTitulo, publicacaoTitulo);
        setTexto(R.id.txtAdminPendenteAutor, "Autor: " + publicacaoAutor);
        setTexto(R.id.txtAdminPendenteGenero, "Gênero: " + publicacaoGenero);
        setTexto(R.id.txtAdminPendenteDescricao, publicacaoDescricao);
        setTexto(R.id.txtAdminPendenteUsuario, "Enviado por: " + publicacaoEmail);
    }




    // Enzo 10
    private void aprovarPublicacao() {
        if (publicacaoPendenteAdminId == -1 && !carregarPublicacaoPendenteDoBanco()) {
            toast("Não há publicações pendentes");
            return;
        }

        boolean livroSalvo = databaseHelper.salvarLivroCatalogo(
                publicacaoTitulo,
                publicacaoAutor,
                publicacaoGenero,
                publicacaoDescricao,
                "Publicação aprovada"
        );

        boolean statusAtualizado = databaseHelper.atualizarStatusPublicacao(
                publicacaoPendenteAdminId,
                "Aprovado"
        );

        if (!livroSalvo || !statusAtualizado) {
            toast("Erro ao aprovar publicação no banco de dados");
            return;
        }

        Map<String, Object> publicacaoFirebase = new HashMap<>();
        publicacaoFirebase.put("idLocal", publicacaoPendenteAdminId);
        publicacaoFirebase.put("uidUsuario", publicacaoEmail);
        publicacaoFirebase.put("email", publicacaoEmail);
        publicacaoFirebase.put("titulo", publicacaoTitulo);
        publicacaoFirebase.put("autor", publicacaoAutor);
        publicacaoFirebase.put("genero", publicacaoGenero);
        publicacaoFirebase.put("descricao", publicacaoDescricao);
        publicacaoFirebase.put("status", "Aprovado");

        Map<String, Object> livroCatalogoFirebase = new HashMap<>();
        livroCatalogoFirebase.put("idLocal", publicacaoPendenteAdminId);
        livroCatalogoFirebase.put("titulo", publicacaoTitulo);
        livroCatalogoFirebase.put("autor", publicacaoAutor);
        livroCatalogoFirebase.put("categoria", publicacaoGenero);
        livroCatalogoFirebase.put("descricao", publicacaoDescricao);
        livroCatalogoFirebase.put("origem", "Publicação aprovada");

        firebaseDb.collection("publicacoes")
                .document("pub_" + publicacaoPendenteAdminId)
                .set(publicacaoFirebase)
                .addOnSuccessListener(aVoid -> {
                    firebaseDb.collection("livros_catalogo")
                            .document("pub_" + publicacaoPendenteAdminId)
                            .set(livroCatalogoFirebase)
                            .addOnSuccessListener(doc -> toast("Publicação aprovada e liberada no Firebase"))
                            .addOnFailureListener(e -> toast("Aprovou, mas erro ao salvar no catálogo Firebase: " + e.getMessage()));
                })
                .addOnFailureListener(e -> {
                    toast("Aprovou localmente, mas deu erro no Firebase: " + e.getMessage());
                });

        carregarLivroExtraDoBanco();
        mostrarAdminPendentes();
    }



    // Enzo 11
    private void recusarPublicacao() {
        if (publicacaoPendenteAdminId == -1 && !carregarPublicacaoPendenteDoBanco()) {
            toast("Não há publicações pendentes");
            return;
        }

        boolean statusAtualizado = databaseHelper.atualizarStatusPublicacao(
                publicacaoPendenteAdminId,
                "Recusado"
        );

        if (!statusAtualizado) {
            toast("Erro ao recusar publicação no banco de dados");
            return;
        }

        Map<String, Object> publicacaoFirebase = new HashMap<>();
        publicacaoFirebase.put("idLocal", publicacaoPendenteAdminId);
        publicacaoFirebase.put("uidUsuario", publicacaoEmail);
        publicacaoFirebase.put("email", publicacaoEmail);
        publicacaoFirebase.put("titulo", publicacaoTitulo);
        publicacaoFirebase.put("autor", publicacaoAutor);
        publicacaoFirebase.put("genero", publicacaoGenero);
        publicacaoFirebase.put("descricao", publicacaoDescricao);
        publicacaoFirebase.put("status", "Recusado");

        firebaseDb.collection("publicacoes")
                .document("pub_" + publicacaoPendenteAdminId)
                .set(publicacaoFirebase)
                .addOnSuccessListener(aVoid -> {
                    toast("Publicação recusada no Firebase");
                })
                .addOnFailureListener(e -> {
                    toast("Recusou localmente, mas deu erro no Firebase: " + e.getMessage());
                });

        toast("Publicação recusada e atualizada no banco");
        mostrarAdminPendentes();
    }



    private void carregarLivroExtraDoBanco() {
        android.database.Cursor c = databaseHelper.getUltimoLivroCatalogo();
        livroExtraCadastrado = c.moveToFirst();
        if (livroExtraCadastrado) {
            extraTitulo = c.getString(c.getColumnIndexOrThrow("titulo"));
            extraAutor = c.getString(c.getColumnIndexOrThrow("autor"));
            extraCategoria = c.getString(c.getColumnIndexOrThrow("categoria"));
            extraDescricao = c.getString(c.getColumnIndexOrThrow("descricao"));
        } else {
            extraTitulo = "";
            extraAutor = "";
            extraCategoria = "";
            extraDescricao = "";
        }
        c.close();
    }


    private void abrirLivroExtra() {
        if (!livroExtraCadastrado) return;
        String capa = extraTitulo.length() > 6 ? extraTitulo.substring(0, 6).toUpperCase() : extraTitulo.toUpperCase();
        selecionarLivro(extraTitulo, extraAutor, extraCategoria, extraDescricao, "⭐ Novo no catálogo", capa, R.drawable.bg_book_blue, Color.rgb(17, 24, 39));
        mostrarDetalhes();
    }

    private void atualizarLivroExtraNoCatalogo() {
        carregarLivroExtraDoBanco();
        View card = findViewById(R.id.cardLivroExtra);
        if (card == null) return;
        card.setVisibility(livroExtraCadastrado ? View.VISIBLE : View.GONE);
        if (!livroExtraCadastrado) return;
        setTexto(R.id.txtExtraTitulo, extraTitulo);
        setTexto(R.id.txtExtraAutor, extraAutor);
        setTexto(R.id.txtExtraCategoria, extraCategoria);
        setTexto(R.id.txtExtraDescricao, extraDescricao);
        TextView capa = findViewById(R.id.txtExtraCapa);
        if (capa != null) {
            String c = extraTitulo.length() > 6 ? extraTitulo.substring(0, 6).toUpperCase() : extraTitulo.toUpperCase();
            capa.setText(c);
        }
    }

    private void configurarBuscaCatalogo() {
        EditText busca = findViewById(R.id.edtBusca);
        if (busca == null) return;
        busca.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { atualizarVisibilidadeCatalogo(s.toString()); }
            @Override public void afterTextChanged(Editable s) { }
        });
    }

    private void aplicarFiltroCatalogo(String filtro) {
        filtroAtual = filtro;
        EditText busca = findViewById(R.id.edtBusca);
        atualizarVisibilidadeCatalogo(busca == null ? "" : texto(busca));
    }

    private void atualizarVisibilidadeCatalogo(String busca) {
        String q = busca == null ? "" : busca.toLowerCase();
        int encontrados = 0;
        encontrados += setLivroVisivel(R.id.cardLivro1, "O Senhor dos Anéis J.R.R. Tolkien Fantasia", q, "Fantasia");
        encontrados += setLivroVisivel(R.id.cardLivro2, "Duna Frank Herbert Ficção Científica", q, "Ficção Científica");
        encontrados += setLivroVisivel(R.id.cardLivro3, "Cell(s) Stephen King Suspense", q, "Suspense");
        encontrados += setLivroVisivel(R.id.cardLivro4, "O Código Da Vinci Dan Brown Mistério", q, "Mistério");
        encontrados += setLivroVisivel(R.id.cardLivro5, "Orgulho e Preconceito Jane Austen Romance", q, "Romance");
        encontrados += setLivroVisivel(R.id.cardLivro6, "1984 George Orwell Distopia", q, "Distopia");
        if (livroExtraCadastrado) {
            encontrados += setLivroVisivel(R.id.cardLivroExtra, extraTitulo + " " + extraAutor + " " + extraCategoria, q, extraCategoria);
        } else {
            View extra = findViewById(R.id.cardLivroExtra);
            if (extra != null) extra.setVisibility(View.GONE);
        }
        setTexto(R.id.txtCatalogoContagem, encontrados + (encontrados == 1 ? " livro encontrado" : " livros encontrados"));
    }

    private int setLivroVisivel(int id, String termos, String busca, String categoria) {
        View card = findViewById(id);
        if (card == null) return 0;
        boolean categoriaOk = filtroAtual.equals("Todos") || categoria.equalsIgnoreCase(filtroAtual);
        boolean buscaOk = busca.isEmpty() || termos.toLowerCase().contains(busca);
        boolean visivel = categoriaOk && buscaOk;
        card.setVisibility(visivel ? View.VISIBLE : View.GONE);
        return visivel ? 1 : 0;
    }

    private void abrirLivroSenhor() {
        selecionarLivro("O Senhor dos Anéis", "J.R.R. Tolkien", "Fantasia", "Uma épica jornada pela Terra Média em busca da destruição do Um Anel.", "⭐ 4.8 (234 avaliações)", "Capa", R.drawable.bg_book_blue, Color.rgb(17, 24, 39));
        mostrarDetalhes();
    }

    private void abrirLivroDuna() {
        selecionarLivro("Duna", "Frank Herbert", "Ficção Científica", "A história do jovem Paul Atreides e sua jornada no deserto planeta Arrakis.", "⭐ 4.6 (189 avaliações)", "DUNA", R.drawable.bg_book_red, Color.WHITE);
        mostrarDetalhes();
    }

    private void abrirLivroCells() {
        selecionarLivro("Cell(s)", "Stephen King", "Suspense", "Uma obra de suspense envolvendo tecnologia, comportamento humano e sobrevivência.", "⭐ 4.4 (110 avaliações)", "CELL(S)", R.drawable.bg_book_gray, Color.rgb(17, 24, 39));
        mostrarDetalhes();
    }

    private void abrirLivroDavinci() {
        selecionarLivro("O Código Da Vinci", "Dan Brown", "Mistério", "Robert Langdon investiga pistas escondidas em obras de arte e símbolos históricos.", "⭐ 4.3 (156 avaliações)", "DA VINCI", R.drawable.bg_book_gray, Color.rgb(17, 24, 39));
        mostrarDetalhes();
    }

    private void abrirLivroOrgulho() {
        selecionarLivro("Orgulho e Preconceito", "Jane Austen", "Romance", "Elizabeth Bennet enfrenta conflitos sociais, orgulho e julgamentos precipitados.", "⭐ 4.7 (201 avaliações)", "P&P", R.drawable.bg_book_blue, Color.rgb(17, 24, 39));
        mostrarDetalhes();
    }

    private void abrirLivro1984() {
        selecionarLivro("1984", "George Orwell", "Distopia", "Uma sociedade vigiada pelo Grande Irmão, marcada por controle, censura e manipulação.", "⭐ 4.9 (310 avaliações)", "1984", R.drawable.bg_book_gray, Color.rgb(17, 24, 39));
        mostrarDetalhes();
    }

    private void selecionarLivro(String titulo, String autor, String categoria, String descricao, String rating, String capa, int background, int textColor) {
        livroTitulo = titulo;
        livroAutor = autor;
        livroCategoria = categoria;
        livroDescricao = descricao;
        livroRating = rating;
        livroCapa = capa;
        livroBackground = background;
        livroTextColor = textColor;
    }

    private void definirLivroMes(String titulo, String autor, String categoria, String descricao, String rating, String capa, int background, int textColor) {
        mesTitulo = titulo;
        mesAutor = autor;
        mesCategoria = categoria;
        mesDescricao = descricao;
        mesRating = rating;
        mesCapa = capa;
        mesBackground = background;
        mesTextColor = textColor;
    }

    private void atualizarLivroMesNaHome() {
        setTexto(R.id.txtLivroMesTitulo, mesTitulo);
        setTexto(R.id.txtLivroMesAutor, mesAutor);
        setTexto(R.id.txtLivroMesRating, mesRating);
        setTexto(R.id.txtLivroMesDescricao, mesDescricao);
        TextView capa = findViewById(R.id.txtLivroMesCapa);
        if (capa != null) {
            capa.setText(mesCapa);
            capa.setBackgroundResource(mesBackground);
            capa.setTextColor(mesTextColor);
        }
    }

    private void atualizarTelaDetalhes() {
        setTexto(R.id.txtDetalheTitulo, livroTitulo);
        setTexto(R.id.txtDetalheAutor, livroAutor);
        setTexto(R.id.txtDetalheCategoria, livroCategoria);
        setTexto(R.id.txtDetalheDescricao, livroDescricao);
        setTexto(R.id.txtDetalheRating, livroRating);
        TextView capa = findViewById(R.id.txtDetalheCapa);
        if (capa != null) {
            capa.setText(livroCapa);
            capa.setBackgroundResource(livroBackground);
            capa.setTextColor(livroTextColor);
        }
    }

    private void atualizarTelaAvaliacao() {
        setTexto(R.id.txtAvaliacaoTitulo, livroTitulo);
        setTexto(R.id.txtAvaliacaoAutor, livroAutor);
        setTexto(R.id.txtAvaliacaoRating, livroRating);
        TextView capa = findViewById(R.id.txtAvaliacaoCapa);
        if (capa != null) {
            capa.setText(livroCapa);
            capa.setBackgroundResource(livroBackground);
            capa.setTextColor(livroTextColor);
        }
    }

    private void configurarBotaoVoltarGlobal() {
        if (telaAtualLayout == R.layout.activity_login) return;

        FrameLayout content = findViewById(android.R.id.content);
        if (content == null) return;

        TextView voltar = new TextView(this);
        voltar.setText("← Voltar");
        voltar.setTextSize(13);
        voltar.setTextColor(Color.rgb(17, 24, 39));
        voltar.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        voltar.setPadding(dp(10), dp(6), dp(10), dp(6));
        voltar.setBackgroundResource(R.drawable.bg_card);
        voltar.setElevation(dp(6));
        voltar.setOnClickListener(v -> voltarPadrao());

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
        );
        params.leftMargin = dp(12);
        params.topMargin = dp(28);
        content.addView(voltar, params);
    }

    private void voltarPadrao() {
        if (telaAtualLayout == R.layout.activity_cadastro || telaAtualLayout == R.layout.activity_recuperar_senha) {
            mostrarLogin();
        } else if (telaAtualLayout == R.layout.activity_home) {
            mostrarLogin();
        } else if (telaAtualLayout == R.layout.activity_catalogo || telaAtualLayout == R.layout.activity_historico || telaAtualLayout == R.layout.activity_publicar || telaAtualLayout == R.layout.activity_perfil) {
            mostrarHome();
        } else if (telaAtualLayout == R.layout.activity_detalhes || telaAtualLayout == R.layout.activity_avaliacao) {
            mostrarCatalogo();
        } else if (telaAtualLayout == R.layout.activity_status_publicacao) {
            mostrarPublicar();
        } else if (telaAtualLayout == R.layout.activity_editar_perfil || telaAtualLayout == R.layout.activity_notificacoes || telaAtualLayout == R.layout.activity_alterar_senha || telaAtualLayout == R.layout.activity_chat || telaAtualLayout == R.layout.activity_admin) {
            mostrarPerfil();
        } else if (telaAtualLayout == R.layout.activity_admin_pendentes || telaAtualLayout == R.layout.activity_adicionar_livro) {
            mostrarAdmin();
        } else {
            mostrarHome();
        }
    }

    private void configurarNavInferior() {
        clicar(R.id.navHome, v -> mostrarHome());
        clicar(R.id.navCatalogo, v -> mostrarCatalogo());
        clicar(R.id.navHistorico, v -> mostrarHistorico());
        clicar(R.id.navPublicar, v -> mostrarPublicar());
        clicar(R.id.navPerfil, v -> mostrarPerfil());
    }

    private void destacarNav(int layoutId) {
        int ativo = 0;
        if (layoutId == R.layout.activity_home) ativo = R.id.navHome;
        else if (layoutId == R.layout.activity_catalogo || layoutId == R.layout.activity_detalhes || layoutId == R.layout.activity_avaliacao) ativo = R.id.navCatalogo;
        else if (layoutId == R.layout.activity_historico) ativo = R.id.navHistorico;
        else if (layoutId == R.layout.activity_publicar || layoutId == R.layout.activity_status_publicacao) ativo = R.id.navPublicar;
        else if (layoutId == R.layout.activity_perfil || layoutId == R.layout.activity_editar_perfil || layoutId == R.layout.activity_notificacoes || layoutId == R.layout.activity_alterar_senha || layoutId == R.layout.activity_chat || layoutId == R.layout.activity_admin || layoutId == R.layout.activity_admin_pendentes) ativo = R.id.navPerfil;

        int[] ids = {R.id.navHome, R.id.navCatalogo, R.id.navHistorico, R.id.navPublicar, R.id.navPerfil};
        for (int id : ids) {
            TextView item = findViewById(id);
            if (item != null) {
                item.setTextColor(id == ativo ? Color.rgb(37, 99, 235) : Color.rgb(31, 41, 55));
                item.setTextSize(id == ativo ? 12 : 11);
            }
        }
    }

    private void clicar(int id, View.OnClickListener listener) {
        View v = findViewById(id);
        if (v != null) {
            v.setOnClickListener(view -> {
                view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(70).withEndAction(() -> {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(90).start();
                    listener.onClick(view);
                }).start();
            });
        }
    }

    private void animarEntrada() {
        View root = getWindow().getDecorView().findViewById(android.R.id.content);
        if (root != null) {
            root.setAlpha(0f);
            root.setTranslationY(18f);
            root.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setDuration(260)
                    .setInterpolator(new DecelerateInterpolator())
                    .start();
        }
    }

    private String texto(EditText editText) {
        if (editText == null || editText.getText() == null) return "";
        return editText.getText().toString().trim();
    }

    private void setTexto(int id, String texto) {
        TextView tv = findViewById(id);
        if (tv != null) tv.setText(texto);
    }

    private void mostrarErro(TextView erro, String mensagem) {
        if (erro != null) {
            erro.setText(mensagem);
            erro.setVisibility(View.VISIBLE);
        }
    }

    private String primeiroNome(String nome) {
        String limpo = nome.trim();
        if (limpo.isEmpty()) return "Usuário";
        String[] partes = limpo.split("\\s+");
        if (partes.length == 0) return limpo;
        String p = partes[0];
        if (p.length() == 0) return "Usuário";
        return p.substring(0, 1).toUpperCase() + p.substring(1);
    }

    private int dp(int valor) {
        return (int) (valor * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
