package com.example.librify;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "librify.db";
    private static final int DATABASE_VERSION = 5;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS usuarios (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT, email TEXT UNIQUE, senha TEXT, admin INTEGER)");

        ContentValues admin = new ContentValues();
        admin.put("nome", "Admin");
        admin.put("email", "admin@librify.com");
        admin.put("senha", "Admin123");
        admin.put("admin", 1);
        db.insert("usuarios", null, admin);

        db.execSQL("CREATE TABLE IF NOT EXISTS historico (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "email TEXT, " +
                "livro TEXT, " +
                "autor TEXT, " +
                "data TEXT, " +
                "categoria TEXT, " +
                "descricao TEXT, " +
                "rating TEXT, " +
                "capa TEXT, " +
                "capa_background INTEGER, " +
                "capa_text_color INTEGER)");

        // Enzo
        db.execSQL("CREATE TABLE IF NOT EXISTS publicacoes (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "email TEXT, " +
                "titulo TEXT, " +
                "autor TEXT, " +
                "genero TEXT, " +
                "descricao TEXT, " +
                "status TEXT, " +
                "data_envio TEXT)");

        // Enzo 2
        db.execSQL("CREATE TABLE IF NOT EXISTS livros_catalogo (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "titulo TEXT, " +
                "autor TEXT, " +
                "categoria TEXT, " +
                "descricao TEXT, " +
                "origem TEXT)");

        // Avaliações dos usuários: salva o nome, a nota e o comentário para aparecer na tela do livro.
        db.execSQL("CREATE TABLE IF NOT EXISTS avaliacoes (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "email TEXT, " +
                "nome_usuario TEXT, " +
                "livro TEXT, " +
                "nota INTEGER, " +
                "comentario TEXT, " +
                "data_envio TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS avaliacoes");
        db.execSQL("DROP TABLE IF EXISTS livros_catalogo");
        db.execSQL("DROP TABLE IF EXISTS publicacoes");
        db.execSQL("DROP TABLE IF EXISTS historico");
        db.execSQL("DROP TABLE IF EXISTS usuarios");
        onCreate(db);
    }

    public boolean cadastrarUsuario(String nome, String email, String senha) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nome", nome);
        values.put("email", email);
        values.put("senha", senha);

        // Se a senha cadastrada for Admin123, o usuário já é salvo como administrador.
        // Qualquer outra senha cria uma conta comum de leitor.
        int admin = senha.equals("Admin123") ? 1 : 0;
        values.put("admin", admin);

        long result = db.insert("usuarios", null, values);
        return result != -1;
    }

    public Cursor validarUsuario(String email, String senha) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT * FROM usuarios WHERE email = ? AND senha = ?",
                new String[]{email, senha}
        );
    }

    public boolean salvarHistorico(String email, String livro, String autor, String data, String categoria, String descricao, String rating, String capa, int capaBackground, int capaTextColor) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("email", email);
        values.put("livro", livro);
        values.put("autor", autor);
        values.put("data", data);
        values.put("categoria", categoria);
        values.put("descricao", descricao);
        values.put("rating", rating);
        values.put("capa", capa);
        values.put("capa_background", capaBackground);
        values.put("capa_text_color", capaTextColor);
        return db.insert("historico", null, values) != -1;
    }

    public Cursor getHistorico(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM historico WHERE email = ? ORDER BY id DESC", new String[]{email});
    }

    public boolean atualizarNome(String email, String novoNome) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nome", novoNome);
        return db.update("usuarios", values, "email=?", new String[]{email}) > 0;
    }

    public boolean atualizarSenha(String email, String novaSenha) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("senha", novaSenha);
        return db.update("usuarios", values, "email=?", new String[]{email}) > 0;
    }

    //Enzo 3
    public boolean salvarPublicacao(String email, String titulo, String autor, String genero, String descricao, String dataEnvio) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("email", email);
        values.put("titulo", titulo);
        values.put("autor", autor);
        values.put("genero", genero);
        values.put("descricao", descricao);
        values.put("status", "Pendente");
        values.put("data_envio", dataEnvio);
        return db.insert("publicacoes", null, values) != -1;
    }

    public Cursor getMinhaUltimaPublicacao(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT * FROM publicacoes WHERE email = ? ORDER BY id DESC LIMIT 1",
                new String[]{email}
        );
    }


    // Enzo 4
    public Cursor getPrimeiraPublicacaoPendente() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT * FROM publicacoes WHERE status = ? ORDER BY id ASC LIMIT 1",
                new String[]{"Pendente"}
        );
    }



    //Enzo 5
    public boolean atualizarStatusPublicacao(int id, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("status", status);
        return db.update("publicacoes", values, "id=?", new String[]{String.valueOf(id)}) > 0;
    }



    //Enzo 6
    public boolean salvarLivroCatalogo(String titulo, String autor, String categoria, String descricao, String origem) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("titulo", titulo);
        values.put("autor", autor);
        values.put("categoria", categoria);
        values.put("descricao", descricao);
        values.put("origem", origem);
        return db.insert("livros_catalogo", null, values) != -1;
    }

    public boolean salvarAvaliacao(String email, String nomeUsuario, String livro, int nota, String comentario, String dataEnvio) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("email", email);
        values.put("nome_usuario", nomeUsuario);
        values.put("livro", livro);
        values.put("nota", nota);
        values.put("comentario", comentario);
        values.put("data_envio", dataEnvio);
        return db.insert("avaliacoes", null, values) != -1;
    }

    public Cursor getAvaliacoesLivro(String livro) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT * FROM avaliacoes WHERE livro = ? ORDER BY id DESC",
                new String[]{livro}
        );
    }

    public Cursor getUltimoLivroCatalogo() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM livros_catalogo ORDER BY id DESC LIMIT 1", null);
    }
}
