package com.example.librify;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class GeminiService {

    private static final String API_KEY = "AQ.Ab8RN6Jbt7kriV0fauzY50LOur2JwMmXgOPGozBvJtGlDnNY8A";

    private static final String URL =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=" + API_KEY;

    private static final MediaType JSON =
            MediaType.parse("application/json; charset=utf-8");

    private static final OkHttpClient client = new OkHttpClient();

    public interface GeminiCallback {
        void onResponse(String resposta);
        void onError(String erro);
    }

    public static void perguntar(String pergunta, GeminiCallback callback) {
        try {
            JSONObject textPart = new JSONObject();
            textPart.put("text", pergunta);

            JSONArray parts = new JSONArray();
            parts.put(textPart);

            JSONObject content = new JSONObject();
            content.put("parts", parts);

            JSONArray contents = new JSONArray();
            contents.put(content);

            JSONObject body = new JSONObject();
            body.put("contents", contents);

            JSONObject generationConfig = new JSONObject();
            generationConfig.put("maxOutputTokens", 512);
            generationConfig.put("temperature", 0.7);
            body.put("generationConfig", generationConfig);

            RequestBody requestBody = RequestBody.create(
                    body.toString(),
                    JSON
            );

            Request request = new Request.Builder()
                    .url(URL)
                    .addHeader("Content-Type", "application/json")
                    .post(requestBody)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    callback.onError("Erro de conexão: " + e.getMessage());
                }

                @Override
                public void onResponse(Call call, Response response) {
                    try {
                        String respostaBruta = response.body() != null
                                ? response.body().string()
                                : "";

                        if (!response.isSuccessful()) {
                            if (response.code() == 429) {
                                callback.onError("Limite gratuito do Gemini atingido. Aguarde um pouco e tente novamente.");
                            } else if (response.code() == 401 || response.code() == 403) {
                                callback.onError("Chave da API Gemini inválida ou sem permissão.");
                            } else {
                                callback.onError("Erro Gemini (" + response.code() + "). Tente novamente.");
                            }
                            return;
                        }

                        JSONObject json = new JSONObject(respostaBruta);
                        JSONArray candidates = json.optJSONArray("candidates");

                        if (candidates == null || candidates.length() == 0) {
                            callback.onError("A IA não retornou resposta.");
                            return;
                        }

                        JSONObject primeiro = candidates.getJSONObject(0);
                        JSONObject content = primeiro.getJSONObject("content");
                        JSONArray parts = content.getJSONArray("parts");

                        String textoResposta = parts
                                .getJSONObject(0)
                                .optString("text", "Sem resposta.");

                        callback.onResponse(textoResposta.trim());

                    } catch (Exception e) {
                        callback.onError("Erro ao ler resposta da IA: " + e.getMessage());
                    } finally {
                        response.close();
                    }
                }
            });

        } catch (Exception e) {
            callback.onError("Erro ao montar requisição: " + e.getMessage());
        }
    }
}
