GEMINI CORRIGIDO

O arquivo GeminiService.java foi ajustado para usar o modelo com cota no projeto:

gemini-2.5-flash-lite

Também foi adicionado maxOutputTokens = 512 para reduzir consumo de tokens e evitar estourar limite rápido.

Depois de abrir o projeto no Android Studio:
1. Clique em Sync Now.
2. Rode no emulador.
3. Teste o chat.

Se aparecer erro de limite, aguarde alguns minutos ou troque a API key por outra com cota disponível.
